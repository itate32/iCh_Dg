package oscurilandia;

public class Ejecutable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		
		Tablero t = new Tablero();
			
		t.crearTablero();
		t.lanzarHuevo();
	


	
	}

}
